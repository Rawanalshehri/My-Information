package com.example.android.bookdb.Data;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.util.Log;

/**
 * Created by HOME on 2/15/2018.
 */

public class BookProvider extends ContentProvider {
    //Tag for the log messages
    public static final String LOG_TAG = BookProvider.class.getSimpleName();
    private static final int BOOK = 100;
    //URI matcher code for the content URI for a single book in the book table
    private static final int BOOK_ID = 101;
    private static final UriMatcher sUriMatcher = new UriMatcher(UriMatcher.NO_MATCH);

    static {
        // The calls to addURI() go here, for all of the content URI patterns that the provider
        // should recognize. All paths added to the UriMatcher have a corresponding code to return
        // when a match is found.
        //HERE bind each URI with specific integer code
        sUriMatcher.addURI(BookContract.CONTENT_AUTHORITY, BookContract.PATH_BOOK, BOOK);
        sUriMatcher.addURI(BookContract.CONTENT_AUTHORITY, BookContract.PATH_BOOK + "/#", BOOK_ID);
    }

    private BookDbHelper bookDbHelper;

    //Database Helper object
    @Override
    public boolean onCreate() {
        bookDbHelper = new BookDbHelper(getContext());
        // Make sure the variable is a global variable, so it can be referenced from other
        // ContentProvider methods.
        return true;
    }

    @Override
    public Cursor query(Uri uri,
                        String[] projection,
                        String selection,
                        String[] selectionArgs,
                        String sortOrder) {
        // ACCESS db USING mdbHelper
        SQLiteDatabase dataBase = bookDbHelper.getReadableDatabase();
        Cursor cursor;
        // Using URiMatcher to find the kind of input URI 100 for hole table and 101 for specific row in table
        int match = sUriMatcher.match(uri);
        switch (match) {
            case BOOK:
                cursor = dataBase.query(BookContract.BookEntry.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder);
                break;
            case BOOK_ID:
                selection = BookContract.BookEntry._ID + "=?";
                selectionArgs = new String[]{String.valueOf(ContentUris.parseId(uri))};
                //SELECT * FROM book WHERE _ID = 3;
                // Cursor containing that row of the table.
                cursor = dataBase.query(BookContract.BookEntry.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder);
                break;
            default:
                throw new IllegalArgumentException("CANNOT query unknown URI: " + uri);
        }
        cursor.setNotificationUri(getContext().getContentResolver(), uri);
        return cursor;
    }

    //Insert new data into the provider with the given ContentValues.
    @Override
    public Uri insert(Uri uri, ContentValues contentValues) {
        //Using URiMatcher to find the kind of input URI
        final int match = sUriMatcher.match(uri);//here will be 100 or 101
        switch (match) {
            case BOOK:
                return insertBook(uri, contentValues);
            default:
                throw new IllegalArgumentException("Insertion is not supported for " + uri.toString());
        }
    }

    private Uri insertBook(Uri uri, ContentValues values) {
        // Check that the name is not null
        String name = values.getAsString(BookContract.BookEntry.COLUMN_BOOK_NAME);
        if (name == null) {
            throw new IllegalArgumentException("Book requires a name");
        }
        //Check that the quantity is valid and not null
        Integer quantity = values.getAsInteger(BookContract.BookEntry.COLUMN_BOOK_QUANTITY);
        if (quantity == null && quantity < 0) {
            throw new IllegalArgumentException("Book requires valid quantity");
        }
        Integer price = values.getAsInteger(BookContract.BookEntry.COLUMN_BOOK_PRICE);
        if (price == null && price < 0) {
            throw new IllegalArgumentException("book requires valid price");
        }
        //Supplier..name, email, number
        String supplier_name = values.getAsString(BookContract.BookEntry.COLUMN_BOOK_SUPPLIER_NAME);
        if (supplier_name == null) {
            throw new IllegalArgumentException("Supplier requires a name");
        }
        String supplier_email = values.getAsString(BookContract.BookEntry.COLUMN_BOOK_SUPPLIER_EMAIL);
        if (supplier_email == null) {
            throw new IllegalArgumentException("Supplier requires a Email");
        }
        Integer supplier_number = values.getAsInteger(BookContract.BookEntry.COLUMN_BOOK_SUPPLIER_NUMBER);
        if (supplier_number == null) {
            throw new IllegalArgumentException("Supplier requires valid number ");
        }
        // Gets the database in write mode
        SQLiteDatabase db = bookDbHelper.getWritableDatabase();
        // Insert the new book with the given values
        // Insert a new row for Toto in the database, returning the ID of that new row.
        long newRowId = db.insert(BookContract.BookEntry.TABLE_NAME,
                null,
                values);
        // If the ID is -1, then the insertion failed. Log an error and return null.
        if (newRowId == -1) {
            Log.e(LOG_TAG, "Failed to insert row" + uri);
            return null;
        }
        // Notify all listeners that the data has changed for the book content URI
        getContext().getContentResolver().notifyChange(uri, null);

        // Return the new URI with the ID (of the newly inserted row) appended at the end
        return ContentUris.withAppendedId(uri, newRowId);
    }

    //Updates the data at the given selection and selection arguments, with the new ContentValues.
    @Override
    public int update(Uri uri, ContentValues contentValues, String selection, String[] selectionArgs) {
        final int match = sUriMatcher.match(uri);
        switch (match) {
            case BOOK:
                return updateBook(uri, contentValues, selection, selectionArgs);
            case BOOK_ID:
                // For the BOOK_ID code, extract out the ID from the URI,
                // so we know which row to update. Selection will be "_id=?" and selection
                // arguments will be a String array containing the actual ID.
                selection = BookContract.BookEntry._ID + "=?";
                selectionArgs = new String[]{String.valueOf(ContentUris.parseId(uri))};
                return updateBook(uri, contentValues, selection, selectionArgs);
            default:
                throw new IllegalArgumentException("Update is not supported for " + uri);
        }
    }

    private int updateBook(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        //Validation the existing Name field
        if (values.containsKey(BookContract.BookEntry.COLUMN_BOOK_SUPPLIER_NAME)) {
            // Check that the name is not null
            String name = values.getAsString(BookContract.BookEntry.COLUMN_BOOK_NAME);
            if (name == null) {
                throw new IllegalArgumentException("Product requires a name");
            }
        }
        if (values.containsKey(BookContract.BookEntry.COLUMN_BOOK_PRICE)) {
            // Check that the price is greater than or equal to 0 $
            Integer price = values.getAsInteger(BookContract.BookEntry.COLUMN_BOOK_PRICE);
            if (price == null && price < 0) {
                throw new IllegalArgumentException("Book requires valid price");
            }
        }
        if (values.containsKey(BookContract.BookEntry.COLUMN_BOOK_SUPPLIER_NAME)) {
            //Check that the supplier_name is valid and not null
            Integer supplierName = values.getAsInteger(BookContract.BookEntry.COLUMN_BOOK_SUPPLIER_NAME);

            if (supplierName == null) {
                throw new IllegalArgumentException("Product requires a name");
            }
        }
        if (values.size() == 0) {
            return 0;
        }
        SQLiteDatabase database = bookDbHelper.getWritableDatabase();
        int rowsUpdated = database.update(BookContract.BookEntry.TABLE_NAME, values, selection, selectionArgs);
        // given URI has changed
        if (rowsUpdated != 0) {
            getContext().getContentResolver().notifyChange(uri, null);
        }
        //Return the number of rows
        return rowsUpdated;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        //write database
        SQLiteDatabase database = bookDbHelper.getWritableDatabase();
        final int match = sUriMatcher.match(uri);
        int rowsDeleted;
        switch (match) {
            case BOOK:
                // Delete all rows
                rowsDeleted = database.delete(BookContract.BookEntry.TABLE_NAME, selection, selectionArgs);
                break;
            case BOOK_ID:
                selection = BookContract.BookEntry._ID + "=?";
                selectionArgs = new String[]{String.valueOf(ContentUris.parseId(uri))};
                rowsDeleted = database.delete(BookContract.BookEntry.TABLE_NAME, selection, selectionArgs);
                break;

            default:
                throw new IllegalArgumentException("Deletion is not supported for " + uri);
        }
        if (rowsDeleted != 0) {
            getContext().getContentResolver().notifyChange(uri, null);
        }
        return rowsDeleted;
    }

    @Override
    public String getType(Uri uri) {
        return null;
    }
}





