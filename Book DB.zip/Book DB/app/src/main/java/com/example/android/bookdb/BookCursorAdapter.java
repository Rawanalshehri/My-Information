package com.example.android.bookdb;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.TextView;
import android.widget.Toast;
import com.example.android.bookdb.Data.BookContract;
import static android.content.ContentValues.TAG;

/**
 * Created by HOME on 2/15/2018.
 */

public class BookCursorAdapter  extends CursorAdapter {

    public BookCursorAdapter(Context context, Cursor c) {
        super(context, c, 0 /* flags */);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return LayoutInflater.from(context).inflate(R.layout.list_item,parent,false);
    }
    @Override
    public void bindView(View view, final Context context, Cursor cursor) {
        TextView name = (TextView) view.findViewById(R.id.book_item_name_text);
        TextView quantity = (TextView) view.findViewById(R.id.book_item_quantity_text);
        TextView price = (TextView) view.findViewById(R.id.book_price);
        final Button orderButton = (Button) view.findViewById(R.id.orderButton);

        final int id = cursor.getInt(cursor.getColumnIndex(BookContract.BookEntry._ID));
        final Uri currentBookUri = ContentUris.withAppendedId(BookContract.BookEntry.CONTENT_URI,id);

        int nameColumnIndex = cursor.getColumnIndex(BookContract.BookEntry.COLUMN_BOOK_NAME);//1
        int priceColumnIndex = cursor.getColumnIndex(BookContract.BookEntry.COLUMN_BOOK_PRICE);//2
        int quantityColumnIndex = cursor.getColumnIndex(BookContract.BookEntry.COLUMN_BOOK_QUANTITY);//3

        String BookName = cursor.getString(nameColumnIndex);
        final Integer BookQuantity = cursor.getInt(quantityColumnIndex);
        Integer BookPrice = cursor.getInt(priceColumnIndex);

        name.setText(BookName);
        quantity.setText(Integer.toString(BookQuantity));
        price.setText(Integer.toString(BookPrice));

        Log.d(TAG, "genero Uri: " + currentBookUri + " Product name: " + nameColumnIndex + " id: " + id);

        orderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("INFO", "ID =============" + id);
                Log.i("INFO", "OLD Quantity " + String.valueOf(BookQuantity));
                ContentResolver resolver = view.getContext().getContentResolver();
                ContentValues values = new ContentValues();
                //BookQuantityRead
                if (BookQuantity > 0) {
                    int quantityValue = BookQuantity;

                    Log.i("INFO", "NEW Quantity " + String.valueOf(quantityValue - 1));
                    values.put(BookContract.BookEntry.COLUMN_BOOK_QUANTITY, quantityValue - 1);
                    resolver.update(
                            currentBookUri,
                            values,
                            null,
                            null);

                    context.getContentResolver().notifyChange(currentBookUri, null);
                } else {
                    Toast.makeText(context, "Product out of stock", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}

