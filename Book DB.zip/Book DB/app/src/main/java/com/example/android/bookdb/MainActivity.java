package com.example.android.bookdb;

import android.app.LoaderManager;
import android.content.ActivityNotFoundException;
import android.content.CursorLoader;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.android.bookdb.Data.BookContract;

public class MainActivity extends AppCompatActivity implements
        LoaderManager.LoaderCallbacks<Cursor>  {

    private static final int LOADER_ID = 0;
    private EditText mNameEditText;
    private EditText mQuantityEditText;
    private Integer quantity;
    private EditText mPriceEditText;
    private EditText mSupplierNameEditText;
    private EditText mSupplierEmailEditText;
    private EditText mSupplierNumberEditText;
    //Content URI for the existing pet (null if it's a new book)
    private Uri mCurrentBookUri;
    private boolean mBookHasChanged = false;

    private View.OnTouchListener mTouchListener = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View view, MotionEvent motionEvent) {
            mBookHasChanged = true;
            return false;
        }
    };

    private Button mOrderButton;
    private Button mPlusButton;
    private Button mLessButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);
        // Examine the intent that was used to launch this activity,
        // in order to figure out if we're creating a new pet or editing an existing one.
        Intent intent = getIntent();
        mCurrentBookUri = intent.getData();
        // If the intent DOES NOT contain a pet content URI, then we know that we are
        // creating a new book.
        if (mCurrentBookUri == null) {
            // This is a new book, so change the app bar to say "Add a book"
            setTitle(getString(R.string.editor_activity_title_new_book));
            // Invalidate the options menu, so the "Delete" menu option can be hidden.
            invalidateOptionsMenu();
        } else {
            // Otherwise this is an existing pet, so change app bar to say "Edit book"
            setTitle(getString(R.string.editor_activity_title_edit_book));

            // display the current values in the editor
            getLoaderManager().initLoader(LOADER_ID, null, this);
        }
        mNameEditText = (EditText) findViewById(R.id.book_name);
        mQuantityEditText = (EditText) findViewById(R.id.edit_Book_quantity);
        mPriceEditText =(EditText)findViewById(R.id.book_price1);
        mSupplierNameEditText = (EditText) findViewById(R.id.supplier_name);
        mSupplierEmailEditText = (EditText)findViewById(R.id.supplier_email);
        mSupplierNumberEditText = (EditText)findViewById(R.id.supplier_number);
        mOrderButton = (Button) findViewById(R.id.orderButton);
        mPlusButton = (Button) findViewById(R.id.Button1);
        mLessButton = (Button) findViewById(R.id.Button2);

        mNameEditText.setOnTouchListener(mTouchListener);
        mQuantityEditText.setOnTouchListener(mTouchListener);
        mPriceEditText.setOnTouchListener(mTouchListener);
        mSupplierNameEditText.setOnTouchListener(mTouchListener);
        mSupplierEmailEditText.setOnTouchListener(mTouchListener);
        mSupplierNumberEditText.setOnTouchListener(mTouchListener);

        mOrderButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                sendEmail();
            }
        });
        mPlusButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (mQuantityEditText.getText().toString().trim().equals("")) {
                    quantity = 0;
                    mQuantityEditText.setText(String.valueOf(quantity));
                } else {
                    quantity = Integer.parseInt(mQuantityEditText.getText().toString().trim());
                    quantity++;
                    mQuantityEditText.setText(String.valueOf(quantity));
                }
            }
        });

        mLessButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (mQuantityEditText.getText().toString().trim().equals("") ||
                        Integer.parseInt(mQuantityEditText.getText().toString().trim()) == 0) {
                    quantity = 0;
                    mQuantityEditText.setText(String.valueOf(quantity));
                }
                else {
                    quantity = Integer.parseInt(mQuantityEditText.getText().toString().trim());
                    quantity--;
                    mQuantityEditText.setText(String.valueOf(quantity));
                }
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // This adds menu items to the app bar.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
        //  "Delete" menu item.
        if (mCurrentBookUri == null) {
            MenuItem menuItem = menu.findItem(R.id.action_delete);
            menuItem.setVisible(false);
        }
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // User clicked on a menu option in the app bar overflow menu
        switch (item.getItemId()) {
            case R.id.action_delete:
                showDeleteConfirmationDialog();
                return true;

            case android.R.id.home:
                if (!mBookHasChanged) {
                    NavUtils.navigateUpFromSameTask(MainActivity.this);
                    return true;
                }
                DialogInterface.OnClickListener discardButtonClickListener =
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                NavUtils.navigateUpFromSameTask(MainActivity.this);
                            }
                        };
                showUnsavedChangesDialog(discardButtonClickListener);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public Loader<Cursor> onCreateLoader(int i, Bundle bundle) {

        // These are the book rows that we will retrieve.
        String[] projection = {
                BookContract.BookEntry._ID,
                BookContract.BookEntry.COLUMN_BOOK_NAME,
                BookContract.BookEntry.COLUMN_BOOK_PRICE,
                BookContract.BookEntry.COLUMN_BOOK_QUANTITY,
                BookContract.BookEntry.COLUMN_BOOK_SUPPLIER_NAME,
                BookContract.BookEntry.COLUMN_BOOK_SUPPLIER_EMAIL,
                BookContract.BookEntry.COLUMN_BOOK_SUPPLIER_NUMBER
        };

        // This loader will execute the ContentProvider's query method on a background thread
        return new CursorLoader(this,   // Parent activity context
                mCurrentBookUri,         // Query the content URI for the current pet
                projection,             // Columns to include in the resulting Cursor
                null,                   // No selection clause
                null,                   // No selection arguments
                null);                  // Default sort order
    }
    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
        // Bail early if the cursor is null or there is less than 1 row in the cursor
        if (cursor == null || cursor.getCount() < 1) {
            return;
        }
        if (cursor.moveToFirst()) {

            int idColumnIndex = cursor.getColumnIndex(BookContract.BookEntry._ID);//0
            int nameColumnIndex = cursor.getColumnIndex(BookContract.BookEntry.COLUMN_BOOK_NAME);//1
            int priceColumnIndex = cursor.getColumnIndex(BookContract.BookEntry.COLUMN_BOOK_PRICE);//2
            int quantityColumnIndex = cursor.getColumnIndex(BookContract.BookEntry.COLUMN_BOOK_QUANTITY);//3
            int supplierNameColumnIndex = cursor.getColumnIndex(BookContract.BookEntry.COLUMN_BOOK_SUPPLIER_NAME);//4
            int supplierEmailColumnIndex = cursor.getColumnIndex(BookContract.BookEntry.COLUMN_BOOK_SUPPLIER_EMAIL);//5
            int supplierNumberColumnIndex = cursor.getColumnIndex(BookContract.BookEntry.COLUMN_BOOK_SUPPLIER_NUMBER);//6

            // Iterate through all the returned rows in the cursor
            while (cursor.moveToNext()) {
                int BookID = cursor.getInt(idColumnIndex);
                String BookName = cursor.getString(nameColumnIndex);
                int BookPrice = cursor.getInt(priceColumnIndex);
                int BookQuantity = cursor.getInt(quantityColumnIndex);
                String SupplierName = cursor.getString(supplierNameColumnIndex);
                String SupplierEmail = cursor.getString(supplierEmailColumnIndex);
                int SupplierNumber = cursor.getInt(supplierNumberColumnIndex);

                mNameEditText.setText(BookName);
                mPriceEditText.setText(Integer.toString(BookPrice));
                mQuantityEditText.setText(Integer.toString(BookQuantity));
                mSupplierNameEditText.setText(SupplierName);
                mSupplierEmailEditText.setText(SupplierEmail);
                mSupplierNumberEditText.setText(SupplierNumber);
            }
        }
    }
    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        // If the loader is invalidated, clear out all the data from the input fields.
        mNameEditText.setText("");
        mQuantityEditText.setText("");
        mPriceEditText.setText("");
        mSupplierNameEditText.setText("");
        mSupplierEmailEditText.setText("");
        mSupplierNumberEditText.setText("");
    }
    private void showUnsavedChangesDialog(
            DialogInterface.OnClickListener discardButtonClickListener) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.unsaved_changes_dialog_msg);
        builder.setPositiveButton(R.string.discard, discardButtonClickListener);
        builder.setNegativeButton(R.string.keep_editing, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicked the "Keep editing" button, so dismiss the dialog
                // and continue editing the pet.
                if (dialog != null) {
                    dialog.dismiss();
                }
            }
        });
        // Create and show the AlertDialog
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
    @Override
    public void onBackPressed() {
        // If the pet hasn't changed, continue with handling back button press
        if (!mBookHasChanged) {
            super.onBackPressed();
            return;
        }

        // Otherwise if there are unsaved changes, setup a dialog to warn the user.
        // Create a click listener to handle the user confirming that changes should be discarded.
        DialogInterface.OnClickListener discardButtonClickListener =
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        finish();
                    }
                };

        // Show dialog that there are unsaved changes
        showUnsavedChangesDialog(discardButtonClickListener);
    }

    private void showDeleteConfirmationDialog() {
        // Create an AlertDialog.Builder and set the message, and click listeners
        // for the postivie and negative buttons on the dialog.
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.delete_dialog_msg);
        builder.setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicked the "Delete" button, so delete the pet.
                deleteBook();
            }
        });
        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicked the "Cancel" button, so dismiss the dialog
                // and continue editing the pet.
                if (dialog != null) {
                    dialog.dismiss();
                }
            }
        });
        // Create and show the AlertDialog
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
    private void deleteBook() {
        // Only perform the delete if this is an existing pet.
        if (mCurrentBookUri != null) {
            // content URI already identifies the pet that we want.
            int rowsDeleted = getContentResolver().delete(mCurrentBookUri, null, null);

            // Show a toast message depending on whether or not the delete was successful.
            if (rowsDeleted == 0) {
                // If no rows were deleted, then there was an error with the delete.
                Toast.makeText(this, getString(R.string.editor_delete_book_failed),
                        Toast.LENGTH_LONG).show();
            } else {
                // Otherwise, the delete was successful and we can display a toast.
                Toast.makeText(this, getString(R.string.editor_delete_book_successful),
                        Toast.LENGTH_LONG).show();
            }
            finish();
        }
    }
    protected void sendEmail() {
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        if (mSupplierEmailEditText.getText().toString().trim().equals("")) {
            Toast.makeText(this, "write Email", Toast.LENGTH_LONG).show();
            return;
        } else if (mSupplierEmailEditText.getText().toString().trim().matches("[a-zA-Z0-9._-]+@[a-z]+.[a-z]+")) {
            Toast.makeText(this, "Invalid Email", Toast.LENGTH_LONG).show();
            return;
        }
        intent.setType("text/plain");
        intent.setData(Uri.parse( mSupplierEmailEditText.getText().toString().trim()));
        intent.putExtra(Intent.EXTRA_SUBJECT, "New order: " + mNameEditText.getText().toString().trim());
        String message = "New order" + mNameEditText.getText().toString().trim() +
                "Quantity " + mQuantityEditText.getText().toString().trim() + " Pcs, " + "\n";
        try
        {startActivity(intent);
            Log.i("Order Button: ", "sending to email");
        }
        catch (ActivityNotFoundException ex) {
            Toast.makeText(MainActivity.this, ex.getMessage().toString(), Toast.LENGTH_SHORT).show();
        }
    }
}
